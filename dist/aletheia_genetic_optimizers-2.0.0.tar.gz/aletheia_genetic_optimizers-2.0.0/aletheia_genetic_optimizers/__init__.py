__version__ = "2.0.0"
from aletheia_genetic_optimizers.individuals import Individual
from aletheia_genetic_optimizers.bounds import BoundCreator
from aletheia_genetic_optimizers.genetic_optimizer import GenethicOptimizer
